// Generated code for this Text Widget...
Text(
  'Search',
  style: FlutterFlowTheme.of(context).bodyLarge.override(
        fontFamily: 'Plus Jakarta Sans',
        color: Color(0xFF15161E),
        fontSize: 16,
        letterSpacing: 0.0,
        fontWeight: FontWeight.w600,
      ),
)
