// Generated code for this Column Widget...
Expanded(
  flex: 4,
  child: Padding(
    padding: EdgeInsetsDirectional.fromSTEB(12, 0, 0, 0),
    child: Column(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Colorize',
          style: FlutterFlowTheme.of(context).bodyLarge.override(
                fontFamily: 'Plus Jakarta Sans',
                color: Color(0xFF15161E),
                fontSize: 16,
                letterSpacing: 0.0,
                fontWeight: FontWeight.w600,
              ),
        ),
      ].divide(SizedBox(height: 4)),
    ),
  ),
)
