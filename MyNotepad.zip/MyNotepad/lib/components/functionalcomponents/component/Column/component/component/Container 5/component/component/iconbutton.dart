// Generated code for this IconButton Widget...
FlutterFlowIconButton(
  borderRadius: 8,
  buttonSize: 40,
  fillColor: FlutterFlowTheme.of(context).primary,
  icon: Icon(
    Icons.category_sharp,
    color: FlutterFlowTheme.of(context).info,
    size: 24,
  ),
  onPressed: () {
    print('IconButton pressed ...');
  },
)
