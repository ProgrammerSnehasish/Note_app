// Generated code for this Text Widget...
InkWell(
  splashColor: Colors.transparent,
  focusColor: Colors.transparent,
  hoverColor: Colors.transparent,
  highlightColor: Colors.transparent,
  onTap: () async {
    context.pushNamed(
      'createnote',
      queryParameters: {
        'notesitem': serializeParam(
          mynotesItem,
          ParamType.String,
        ),
      }.withoutNulls,
    );
  },
  child: Text(
    mynotesItem,
    style: FlutterFlowTheme.of(context).bodyLarge.override(
          fontFamily: 'Plus Jakarta Sans',
          color: Color(0xFF060608),
          fontSize: 16,
          letterSpacing: 0.0,
          fontWeight: FontWeight.w600,
        ),
  ),
)
