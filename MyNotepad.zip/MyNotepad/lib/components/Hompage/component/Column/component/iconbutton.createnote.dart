// Generated code for this IconButton Widget...
Align(
  alignment: AlignmentDirectional(1, 1),
  child: Padding(
    padding: EdgeInsetsDirectional.fromSTEB(0, 550, 10, 0),
    child: FlutterFlowIconButton(
      borderRadius: 8,
      buttonSize: 60,
      fillColor: FlutterFlowTheme.of(context).primary,
      icon: Icon(
        Icons.add,
        color: FlutterFlowTheme.of(context).info,
        size: 24,
      ),
      onPressed: () async {
        context.pushNamed(
          'createnote',
          queryParameters: {
            'notesitem': serializeParam(
              '',
              ParamType.String,
            ),
          }.withoutNulls,
        );
      },
    ),
  ),
)
