// Generated code for this ListView Widget...
Builder(
  builder: (context) {
    final mynotes = FFAppState().note.toList();
    return ListView.builder(
      padding: EdgeInsets.zero,
      shrinkWrap: true,
      scrollDirection: Axis.vertical,
      itemCount: mynotes.length,
      itemBuilder: (context, mynotesIndex) {
        final mynotesItem = mynotes[mynotesIndex];
        return Padding(
          padding: EdgeInsetsDirectional.fromSTEB(12, 0, 0, 0),
          child: InkWell(
            splashColor: Colors.transparent,
            focusColor: Colors.transparent,
            hoverColor: Colors.transparent,
            highlightColor: Colors.transparent,
            onTap: () async {
              FFAppState().note = FFAppState().note.toList().cast<String>();
              safeSetState(() {});
              context.pushNamed(
                'createnote',
                queryParameters: {
                  'notesitem': serializeParam(
                    mynotesItem,
                    ParamType.String,
                  ),
                }.withoutNulls,
              );
            },
            child: Column(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                InkWell(
                  splashColor: Colors.transparent,
                  focusColor: Colors.transparent,
                  hoverColor: Colors.transparent,
                  highlightColor: Colors.transparent,
                  onTap: () async {
                    context.pushNamed(
                      'createnote',
                      queryParameters: {
                        'notesitem': serializeParam(
                          mynotesItem,
                          ParamType.String,
                        ),
                      }.withoutNulls,
                    );
                  },
                  child: Text(
                    mynotesItem,
                    style: FlutterFlowTheme.of(context).bodyLarge.override(
                          fontFamily: 'Plus Jakarta Sans',
                          color: Color(0xFF060608),
                          fontSize: 16,
                          letterSpacing: 0.0,
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                ),
              ].divide(SizedBox(height: 4)),
            ),
          ),
        );
      },
    );
  },
)
