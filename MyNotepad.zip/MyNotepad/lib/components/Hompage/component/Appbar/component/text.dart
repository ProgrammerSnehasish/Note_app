// Generated code for this Text Widget...
Text(
  'My Notepad',
  style: FlutterFlowTheme.of(context).headlineMedium.override(
        fontFamily: 'Inter Tight',
        color: Colors.white,
        fontSize: 22,
        letterSpacing: 0.0,
      ),
)
