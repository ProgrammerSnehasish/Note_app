// Generated code for this AppBar Widget...
AppBar(
  backgroundColor: FlutterFlowTheme.of(context).primary,
  automaticallyImplyLeading: false,
  leading: FlutterFlowIconButton(
    borderRadius: 8,
    buttonSize: 40,
    fillColor: FlutterFlowTheme.of(context).primary,
    icon: Icon(
      Icons.dehaze,
      color: FlutterFlowTheme.of(context).info,
      size: 24,
    ),
    onPressed: () async {
      context.pushNamed('aboutandconfigapp');
    },
  ),
  title: Text(
    'My Notepad',
    style: FlutterFlowTheme.of(context).headlineMedium.override(
          fontFamily: 'Inter Tight',
          color: Colors.white,
          fontSize: 22,
          letterSpacing: 0.0,
        ),
  ),
  actions: [
    FlutterFlowIconButton(
      borderRadius: 8,
      buttonSize: 40,
      fillColor: FlutterFlowTheme.of(context).primary,
      icon: Icon(
        Icons.search_outlined,
        color: FlutterFlowTheme.of(context).info,
        size: 24,
      ),
      onPressed: () {
        print('IconButton pressed ...');
      },
    ),
    Padding(
      padding: EdgeInsetsDirectional.fromSTEB(0, 0, 3, 0),
      child: FlutterFlowIconButton(
        borderRadius: 8,
        buttonSize: 40,
        fillColor: FlutterFlowTheme.of(context).primary,
        icon: Icon(
          Icons.format_list_bulleted_sharp,
          color: FlutterFlowTheme.of(context).info,
          size: 24,
        ),
        onPressed: () async {
          context.pushNamed('otherutils');
        },
      ),
    ),
  ],
  centerTitle: false,
  elevation: 2,
)
