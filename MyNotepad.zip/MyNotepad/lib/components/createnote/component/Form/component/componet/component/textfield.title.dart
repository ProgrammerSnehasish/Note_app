// Generated code for this TextField Widget...
Align(
  alignment: AlignmentDirectional(0, -1),
  child: Container(
    width: 500,
    child: TextFormField(
      controller: _model.textController1,
      focusNode: _model.textFieldFocusNode1,
      onFieldSubmitted: (_) async {
        FFAppState().addToNote(widget!.notesitem!);
        safeSetState(() {});
        final selectedFiles = await selectFiles(
          multiFile: false,
        );
        if (selectedFiles != null) {
          safeSetState(() => _model.isDataUploading1 = true);
          var selectedUploadedFiles = <FFUploadedFile>[];
          try {
            selectedUploadedFiles = selectedFiles
                .map((m) => FFUploadedFile(
                      name: m.storagePath.split('/').last,
                      bytes: m.bytes,
                    ))
                .toList();
          } finally {
            _model.isDataUploading1 = false;
          }
          if (selectedUploadedFiles.length == selectedFiles.length) {
            safeSetState(() {
              _model.uploadedLocalFile1 = selectedUploadedFiles.first;
            });
          } else {
            safeSetState(() {});
            return;
          }
        }
      },
      autofocus: false,
      obscureText: false,
      decoration: InputDecoration(
        isDense: true,
        labelStyle: FlutterFlowTheme.of(context).labelMedium.override(
              fontFamily: 'Inter',
              letterSpacing: 0.0,
            ),
        hintText: 'Title...',
        hintStyle: FlutterFlowTheme.of(context).labelMedium.override(
              fontFamily: 'Open Sans',
              letterSpacing: 0.0,
            ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: Color(0x00000000),
            width: 1,
          ),
          borderRadius: BorderRadius.circular(8),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: Color(0x00000000),
            width: 1,
          ),
          borderRadius: BorderRadius.circular(8),
        ),
        errorBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: FlutterFlowTheme.of(context).error,
            width: 1,
          ),
          borderRadius: BorderRadius.circular(8),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: FlutterFlowTheme.of(context).error,
            width: 1,
          ),
          borderRadius: BorderRadius.circular(8),
        ),
        filled: true,
        fillColor: FlutterFlowTheme.of(context).secondaryBackground,
      ),
      style: FlutterFlowTheme.of(context).bodyMedium.override(
            fontFamily: 'Inter',
            letterSpacing: 0.0,
          ),
      cursorColor: FlutterFlowTheme.of(context).primaryText,
      validator: _model.textController1Validator.asValidator(context),
    ),
  ),
)
