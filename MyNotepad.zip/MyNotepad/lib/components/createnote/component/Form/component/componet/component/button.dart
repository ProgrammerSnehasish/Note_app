// Generated code for this Button Widget...
FFButtonWidget(
  onPressed: () async {
    if (_model.formKey.currentState == null ||
        !_model.formKey.currentState!.validate()) {
      return;
    }
    FFAppState().addToNote(widget!.notesitem!);
    safeSetState(() {});
    context.pushNamed('HomePage');
  },
  text: 'SAVE',
  options: FFButtonOptions(
    height: 40,
    padding: EdgeInsetsDirectional.fromSTEB(16, 0, 16, 0),
    iconPadding: EdgeInsetsDirectional.fromSTEB(0, 0, 0, 0),
    color: FlutterFlowTheme.of(context).primary,
    textStyle: FlutterFlowTheme.of(context).titleSmall.override(
          fontFamily: 'Inter Tight',
          color: Colors.white,
          letterSpacing: 0.0,
        ),
    elevation: 0,
    borderRadius: BorderRadius.circular(8),
  ),
)
