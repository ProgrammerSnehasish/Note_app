// Generated code for this TextField Widget...
TextFormField(
  controller: _model.textController2,
  focusNode: _model.textFieldFocusNode2,
  onFieldSubmitted: (_) async {
    FFAppState().addToNote('');
    safeSetState(() {});
    final selectedFiles = await selectFiles(
      multiFile: false,
    );
    if (selectedFiles != null) {
      safeSetState(() => _model.isDataUploading2 = true);
      var selectedUploadedFiles = <FFUploadedFile>[];
      try {
        selectedUploadedFiles = selectedFiles
            .map((m) => FFUploadedFile(
                  name: m.storagePath.split('/').last,
                  bytes: m.bytes,
                ))
            .toList();
      } finally {
        _model.isDataUploading2 = false;
      }
      if (selectedUploadedFiles.length == selectedFiles.length) {
        safeSetState(() {
          _model.uploadedLocalFile2 = selectedUploadedFiles.first;
        });
      } else {
        safeSetState(() {});
        return;
      }
    }
  },
  autofocus: true,
  obscureText: false,
  decoration: InputDecoration(
    labelStyle: FlutterFlowTheme.of(context).labelMedium.override(
          fontFamily: 'Plus Jakarta Sans',
          color: Color(0xFF606A85),
          fontSize: 14,
          letterSpacing: 0.0,
          fontWeight: FontWeight.w500,
        ),
    hintText: 'Add your note...',
    hintStyle: FlutterFlowTheme.of(context).labelMedium.override(
          fontFamily: 'Plus Jakarta Sans',
          color: Color(0xFF606A85),
          fontSize: 14,
          letterSpacing: 0.0,
          fontWeight: FontWeight.w500,
        ),
    enabledBorder: UnderlineInputBorder(
      borderSide: BorderSide(
        color: Color(0xFFE5E7EB),
        width: 2,
      ),
      borderRadius: BorderRadius.circular(0),
    ),
    focusedBorder: UnderlineInputBorder(
      borderSide: BorderSide(
        color: Color(0xFF6F61EF),
        width: 2,
      ),
      borderRadius: BorderRadius.circular(0),
    ),
    errorBorder: UnderlineInputBorder(
      borderSide: BorderSide(
        color: Color(0xFFFF5963),
        width: 2,
      ),
      borderRadius: BorderRadius.circular(0),
    ),
    focusedErrorBorder: UnderlineInputBorder(
      borderSide: BorderSide(
        color: Color(0xFFFF5963),
        width: 2,
      ),
      borderRadius: BorderRadius.circular(0),
    ),
    contentPadding: EdgeInsetsDirectional.fromSTEB(10, 0, 0, 550),
  ),
  style: FlutterFlowTheme.of(context).bodyMedium.override(
        fontFamily: 'Plus Jakarta Sans',
        color: Color(0xFF15161E),
        fontSize: 14,
        letterSpacing: 0.0,
        fontWeight: FontWeight.w500,
      ),
  maxLines: 30,
  minLines: 6,
  maxLength: 10000,
  maxLengthEnforcement: MaxLengthEnforcement.enforced,
  buildCounter: (context,
          {required currentLength, required isFocused, maxLength}) =>
      null,
  cursorColor: Color(0xFF6F61EF),
  validator: _model.textController2Validator.asValidator(context),
)
