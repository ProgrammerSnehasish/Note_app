// Generated code for this IconButton Widget...
Padding(
  padding: EdgeInsetsDirectional.fromSTEB(0, 0, 3, 0),
  child: FlutterFlowIconButton(
    borderRadius: 8,
    buttonSize: 46.7,
    fillColor: FlutterFlowTheme.of(context).primary,
    icon: Icon(
      Icons.dehaze,
      color: FlutterFlowTheme.of(context).info,
      size: 24,
    ),
    onPressed: () async {
      context.pushNamed('functionalcomponents');
    },
  ),
)
