// Generated code for this IconButton Widget...
FlutterFlowIconButton(
  borderRadius: 8,
  buttonSize: 40,
  fillColor: FlutterFlowTheme.of(context).primary,
  icon: Icon(
    Icons.restore_from_trash_rounded,
    color: FlutterFlowTheme.of(context).info,
    size: 24,
  ),
  onPressed: () async {
    FFAppState().removeFromNote(widget!.notesitem!);
    safeSetState(() {});
    context.safePop();
  },
)
