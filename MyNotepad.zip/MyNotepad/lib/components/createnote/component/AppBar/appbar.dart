// Generated code for this AppBar Widget...
AppBar(
  backgroundColor: FlutterFlowTheme.of(context).primary,
  automaticallyImplyLeading: false,
  leading: FlutterFlowIconButton(
    borderRadius: 8,
    buttonSize: 40,
    fillColor: FlutterFlowTheme.of(context).primary,
    icon: Icon(
      Icons.arrow_back,
      color: FlutterFlowTheme.of(context).info,
      size: 24,
    ),
    onPressed: () async {
      context.pushNamed('HomePage');
    },
  ),
  title: Text(
    'My Notepad',
    style: FlutterFlowTheme.of(context).headlineMedium.override(
          fontFamily: 'Inter Tight',
          color: Colors.white,
          fontSize: 22,
          letterSpacing: 0.0,
        ),
  ),
  actions: [
    FlutterFlowIconButton(
      borderRadius: 8,
      buttonSize: 40,
      fillColor: FlutterFlowTheme.of(context).primary,
      icon: Icon(
        Icons.restore_from_trash_rounded,
        color: FlutterFlowTheme.of(context).info,
        size: 24,
      ),
      onPressed: () async {
        FFAppState().removeFromNote(widget!.notesitem!);
        safeSetState(() {});
        context.safePop();
      },
    ),
    FlutterFlowIconButton(
      borderRadius: 8,
      buttonSize: 40,
      fillColor: FlutterFlowTheme.of(context).primary,
      icon: Icon(
        Icons.undo_sharp,
        color: FlutterFlowTheme.of(context).info,
        size: 24,
      ),
      onPressed: () {
        print('IconButton pressed ...');
      },
    ),
    Padding(
      padding: EdgeInsetsDirectional.fromSTEB(0, 0, 3, 0),
      child: FlutterFlowIconButton(
        borderRadius: 8,
        buttonSize: 46.7,
        fillColor: FlutterFlowTheme.of(context).primary,
        icon: Icon(
          Icons.dehaze,
          color: FlutterFlowTheme.of(context).info,
          size: 24,
        ),
        onPressed: () async {
          context.pushNamed('functionalcomponents');
        },
      ),
    ),
  ],
  centerTitle: false,
  elevation: 2,
)
