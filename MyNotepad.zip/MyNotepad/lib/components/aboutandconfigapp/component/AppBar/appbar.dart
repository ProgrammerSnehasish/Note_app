// Generated code for this AppBar Widget...
AppBar(
  backgroundColor: FlutterFlowTheme.of(context).primary,
  automaticallyImplyLeading: false,
  leading: FlutterFlowIconButton(
    borderRadius: 8,
    buttonSize: 40,
    fillColor: FlutterFlowTheme.of(context).primary,
    icon: Icon(
      Icons.arrow_back,
      color: FlutterFlowTheme.of(context).info,
      size: 24,
    ),
    onPressed: () async {
      context.pushNamed('HomePage');
    },
  ),
  title: Text(
    'My Notepad',
    style: FlutterFlowTheme.of(context).headlineMedium.override(
          fontFamily: 'Inter Tight',
          color: Colors.white,
          fontSize: 22,
          letterSpacing: 0.0,
        ),
  ),
  actions: [],
  centerTitle: false,
  elevation: 2,
)
