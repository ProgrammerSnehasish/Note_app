// Generated code for this Text Widget...
if (responsiveVisibility(
  context: context,
  phone: false,
  tablet: false,
))
  Expanded(
    flex: 3,
    child: Align(
      alignment: AlignmentDirectional(-1, 0),
      child: Text(
        'Head of Design',
        style: FlutterFlowTheme.of(context).bodyMedium.override(
              fontFamily: 'Plus Jakarta Sans',
              color: Color(0xFF15161E),
              fontSize: 14,
              letterSpacing: 0.0,
              fontWeight: FontWeight.w500,
            ),
      ),
    ),
  )
