// Generated code for this Text Widget...
InkWell(
  splashColor: Colors.transparent,
  focusColor: Colors.transparent,
  hoverColor: Colors.transparent,
  highlightColor: Colors.transparent,
  onTap: () async {
    context.pushNamed('HomePage');
  },
  child: Text(
    'Notes',
    style: FlutterFlowTheme.of(context).bodyLarge.override(
          fontFamily: 'Plus Jakarta Sans',
          color: Color(0xFF15161E),
          fontSize: 16,
          letterSpacing: 0.0,
          fontWeight: FontWeight.w600,
        ),
  ),
)
