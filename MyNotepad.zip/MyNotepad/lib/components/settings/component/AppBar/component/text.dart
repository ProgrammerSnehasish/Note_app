// Generated code for this Text Widget...
Text(
  'Settings',
  style: FlutterFlowTheme.of(context).headlineMedium.override(
        fontFamily: 'Inter Tight',
        color: FlutterFlowTheme.of(context).info,
        fontSize: 22,
        letterSpacing: 0.0,
      ),
)
