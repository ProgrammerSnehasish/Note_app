// Generated code for this Text Widget...
Text(
  'Use Device Backup',
  style: FlutterFlowTheme.of(context).bodyLarge.override(
        fontFamily: 'Inter',
        letterSpacing: 0.0,
      ),
)
