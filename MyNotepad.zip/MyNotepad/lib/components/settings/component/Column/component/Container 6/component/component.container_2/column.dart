// Generated code for this Column Widget...
Column(
  mainAxisSize: MainAxisSize.max,
  crossAxisAlignment: CrossAxisAlignment.start,
  children: [
    Text(
      'Terms of Service',
      style: FlutterFlowTheme.of(context).bodyLarge.override(
            fontFamily: 'Inter',
            letterSpacing: 0.0,
          ),
    ),
    Text(
      'Read our terms of service',
      style: FlutterFlowTheme.of(context).bodySmall.override(
            fontFamily: 'Inter',
            color: FlutterFlowTheme.of(context).secondaryText,
            letterSpacing: 0.0,
          ),
    ),
  ],
)
