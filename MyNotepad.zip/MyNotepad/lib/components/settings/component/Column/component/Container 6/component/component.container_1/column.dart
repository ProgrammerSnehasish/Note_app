// Generated code for this Column Widget...
Column(
  mainAxisSize: MainAxisSize.max,
  crossAxisAlignment: CrossAxisAlignment.start,
  children: [
    Text(
      'Privacy Policy',
      style: FlutterFlowTheme.of(context).bodyLarge.override(
            fontFamily: 'Inter',
            letterSpacing: 0.0,
          ),
    ),
    Text(
      'Read our privacy policy',
      style: FlutterFlowTheme.of(context).bodySmall.override(
            fontFamily: 'Inter',
            color: FlutterFlowTheme.of(context).secondaryText,
            letterSpacing: 0.0,
          ),
    ),
  ],
)
