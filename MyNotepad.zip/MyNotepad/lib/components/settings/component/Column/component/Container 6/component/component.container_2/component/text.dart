// Generated code for this Text Widget...
Text(
  'Terms of Service',
  style: FlutterFlowTheme.of(context).bodyLarge.override(
        fontFamily: 'Inter',
        letterSpacing: 0.0,
      ),
)
