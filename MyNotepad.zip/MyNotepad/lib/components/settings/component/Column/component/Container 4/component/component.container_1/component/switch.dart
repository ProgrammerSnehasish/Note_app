// Generated code for this Switch Widget...
Switch(
  value: _model.switchValue3!,
  onChanged: (newValue) async {
    safeSetState(() => _model.switchValue3 = newValue!);
  },
  activeColor: FlutterFlowTheme.of(context).primary,
  activeTrackColor: FlutterFlowTheme.of(context).secondaryText,
  inactiveTrackColor: FlutterFlowTheme.of(context).secondaryText,
  inactiveThumbColor: FlutterFlowTheme.of(context).secondaryText,
)
