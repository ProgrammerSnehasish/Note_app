// Generated code for this Icon Widget...
Icon(
  Icons.chevron_right,
  color: FlutterFlowTheme.of(context).secondaryText,
  size: 24,
)
