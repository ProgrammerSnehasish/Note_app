// Generated code for this Container Widget...
Container(
  width: MediaQuery.sizeOf(context).width,
  decoration: BoxDecoration(
    color: FlutterFlowTheme.of(context).primaryBackground,
    borderRadius: BorderRadius.circular(8),
  ),
  child: Padding(
    padding: EdgeInsetsDirectional.fromSTEB(12, 12, 12, 12),
    child: Row(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          'Move Deleted Notes to Trash',
          style: FlutterFlowTheme.of(context).bodyLarge.override(
                fontFamily: 'Inter',
                letterSpacing: 0.0,
              ),
        ),
        Switch(
          value: _model.switchValue5!,
          onChanged: (newValue) async {
            safeSetState(() => _model.switchValue5 = newValue!);
          },
          activeColor: FlutterFlowTheme.of(context).primary,
          activeTrackColor: FlutterFlowTheme.of(context).secondaryText,
          inactiveTrackColor: FlutterFlowTheme.of(context).secondaryText,
          inactiveThumbColor: FlutterFlowTheme.of(context).secondaryText,
        ),
      ],
    ),
  ),
)
