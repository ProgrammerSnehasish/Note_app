// Generated code for this Text Widget...
Text(
  'Auto Save',
  style: FlutterFlowTheme.of(context).bodyLarge.override(
        fontFamily: 'Inter',
        letterSpacing: 0.0,
      ),
)
