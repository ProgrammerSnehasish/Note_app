// Generated code for this Text Widget...
Text(
  'App Preferences',
  style: FlutterFlowTheme.of(context).headlineSmall.override(
        fontFamily: 'Inter Tight',
        color: FlutterFlowTheme.of(context).primaryText,
        letterSpacing: 0.0,
        fontWeight: FontWeight.w600,
      ),
)
