// Generated code for this Switch Widget...
Switch(
  value: _model.switchValue1!,
  onChanged: (newValue) async {
    safeSetState(() => _model.switchValue1 = newValue!);
  },
  activeColor: FlutterFlowTheme.of(context).primary,
  activeTrackColor: FlutterFlowTheme.of(context).secondaryText,
  inactiveTrackColor: Color(0xFF1279C7),
  inactiveThumbColor: FlutterFlowTheme.of(context).secondaryText,
)
