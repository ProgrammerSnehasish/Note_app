// Generated code for this Container Widget...
Container(
  width: MediaQuery.sizeOf(context).width,
  decoration: BoxDecoration(
    color: FlutterFlowTheme.of(context).primaryBackground,
    borderRadius: BorderRadius.circular(8),
  ),
  child: Padding(
    padding: EdgeInsetsDirectional.fromSTEB(12, 12, 12, 12),
    child: Row(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          'Sort Notes By',
          style: FlutterFlowTheme.of(context).bodyLarge.override(
                fontFamily: 'Inter',
                letterSpacing: 0.0,
              ),
        ),
        Text(
          'Date Modified',
          style: FlutterFlowTheme.of(context).bodyLarge.override(
                fontFamily: 'Inter',
                color: FlutterFlowTheme.of(context).primary,
                letterSpacing: 0.0,
              ),
        ),
      ],
    ),
  ),
)
