// Generated code for this Text Widget...
Text(
  '14',
  style: FlutterFlowTheme.of(context).bodyLarge.override(
        fontFamily: 'Inter',
        color: FlutterFlowTheme.of(context).primary,
        letterSpacing: 0.0,
      ),
)
