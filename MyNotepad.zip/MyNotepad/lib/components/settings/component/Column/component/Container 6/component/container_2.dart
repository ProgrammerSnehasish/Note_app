// Generated code for this Container Widget...
Container(
  width: MediaQuery.sizeOf(context).width,
  decoration: BoxDecoration(
    color: FlutterFlowTheme.of(context).primaryBackground,
    borderRadius: BorderRadius.circular(8),
  ),
  child: Padding(
    padding: EdgeInsetsDirectional.fromSTEB(12, 12, 12, 12),
    child: Row(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          mainAxisSize: MainAxisSize.max,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Terms of Service',
              style: FlutterFlowTheme.of(context).bodyLarge.override(
                    fontFamily: 'Inter',
                    letterSpacing: 0.0,
                  ),
            ),
            Text(
              'Read our terms of service',
              style: FlutterFlowTheme.of(context).bodySmall.override(
                    fontFamily: 'Inter',
                    color: FlutterFlowTheme.of(context).secondaryText,
                    letterSpacing: 0.0,
                  ),
            ),
          ],
        ),
        Icon(
          Icons.chevron_right,
          color: FlutterFlowTheme.of(context).secondaryText,
          size: 24,
        ),
      ],
    ),
  ),
)
