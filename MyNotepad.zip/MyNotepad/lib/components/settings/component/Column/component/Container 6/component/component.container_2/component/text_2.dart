// Generated code for this Text Widget...
Text(
  'Read our terms of service',
  style: FlutterFlowTheme.of(context).bodySmall.override(
        fontFamily: 'Inter',
        color: FlutterFlowTheme.of(context).secondaryText,
        letterSpacing: 0.0,
      ),
)
