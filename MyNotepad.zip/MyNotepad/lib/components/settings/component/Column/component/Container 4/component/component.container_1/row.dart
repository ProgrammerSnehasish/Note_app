// Generated code for this Row Widget...
Padding(
  padding: EdgeInsetsDirectional.fromSTEB(12, 12, 12, 12),
  child: Row(
    mainAxisSize: MainAxisSize.max,
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(
        'App Lock',
        style: FlutterFlowTheme.of(context).bodyLarge.override(
              fontFamily: 'Inter',
              letterSpacing: 0.0,
            ),
      ),
      Switch(
        value: _model.switchValue3!,
        onChanged: (newValue) async {
          safeSetState(() => _model.switchValue3 = newValue!);
        },
        activeColor: FlutterFlowTheme.of(context).primary,
        activeTrackColor: FlutterFlowTheme.of(context).secondaryText,
        inactiveTrackColor: FlutterFlowTheme.of(context).secondaryText,
        inactiveThumbColor: FlutterFlowTheme.of(context).secondaryText,
      ),
    ],
  ),
)
