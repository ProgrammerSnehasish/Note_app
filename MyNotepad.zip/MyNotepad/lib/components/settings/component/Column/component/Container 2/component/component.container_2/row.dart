// Generated code for this Row Widget...
Padding(
  padding: EdgeInsetsDirectional.fromSTEB(12, 12, 12, 12),
  child: Row(
    mainAxisSize: MainAxisSize.max,
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(
        'Sort Notes By',
        style: FlutterFlowTheme.of(context).bodyLarge.override(
              fontFamily: 'Inter',
              letterSpacing: 0.0,
            ),
      ),
      Text(
        'Date Modified',
        style: FlutterFlowTheme.of(context).bodyLarge.override(
              fontFamily: 'Inter',
              color: FlutterFlowTheme.of(context).primary,
              letterSpacing: 0.0,
            ),
      ),
    ],
  ),
)
