// Generated code for this Text Widget...
Text(
  'App Lock',
  style: FlutterFlowTheme.of(context).bodyLarge.override(
        fontFamily: 'Inter',
        letterSpacing: 0.0,
      ),
)
