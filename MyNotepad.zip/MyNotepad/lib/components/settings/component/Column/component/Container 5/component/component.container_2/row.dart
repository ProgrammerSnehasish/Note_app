// Generated code for this Row Widget...
Padding(
  padding: EdgeInsetsDirectional.fromSTEB(12, 12, 12, 12),
  child: Row(
    mainAxisSize: MainAxisSize.max,
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(
        'Use Device Backup',
        style: FlutterFlowTheme.of(context).bodyLarge.override(
              fontFamily: 'Inter',
              letterSpacing: 0.0,
            ),
      ),
      Switch(
        value: _model.switchValue6!,
        onChanged: (newValue) async {
          safeSetState(() => _model.switchValue6 = newValue!);
        },
        activeColor: FlutterFlowTheme.of(context).primary,
        activeTrackColor: FlutterFlowTheme.of(context).secondaryText,
        inactiveTrackColor: FlutterFlowTheme.of(context).secondaryText,
        inactiveThumbColor: FlutterFlowTheme.of(context).secondaryText,
      ),
    ],
  ),
)
