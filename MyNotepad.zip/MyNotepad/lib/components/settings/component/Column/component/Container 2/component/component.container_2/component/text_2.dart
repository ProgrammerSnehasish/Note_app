// Generated code for this Text Widget...
Text(
  'Date Modified',
  style: FlutterFlowTheme.of(context).bodyLarge.override(
        fontFamily: 'Inter',
        color: FlutterFlowTheme.of(context).primary,
        letterSpacing: 0.0,
      ),
)
