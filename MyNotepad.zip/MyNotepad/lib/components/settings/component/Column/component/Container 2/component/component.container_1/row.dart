// Generated code for this Row Widget...
Padding(
  padding: EdgeInsetsDirectional.fromSTEB(12, 12, 12, 12),
  child: Row(
    mainAxisSize: MainAxisSize.max,
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(
        'Default Font Size',
        style: FlutterFlowTheme.of(context).bodyLarge.override(
              fontFamily: 'Inter',
              letterSpacing: 0.0,
            ),
      ),
      Text(
        '14',
        style: FlutterFlowTheme.of(context).bodyLarge.override(
              fontFamily: 'Inter',
              color: FlutterFlowTheme.of(context).primary,
              letterSpacing: 0.0,
            ),
      ),
    ],
  ),
)
