// Generated code for this Text Widget...
Text(
  'Sort Notes By',
  style: FlutterFlowTheme.of(context).bodyLarge.override(
        fontFamily: 'Inter',
        letterSpacing: 0.0,
      ),
)
