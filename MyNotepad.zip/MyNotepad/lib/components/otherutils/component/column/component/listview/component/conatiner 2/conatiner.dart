// Generated code for this Container Widget...
Container(
  width: 100,
  height: 100,
  decoration: BoxDecoration(
    color: FlutterFlowTheme.of(context).secondaryBackground,
  ),
  child: Align(
    alignment: AlignmentDirectional(0, 0),
    child: Text(
      'Import text files',
      style: FlutterFlowTheme.of(context).bodyMedium.override(
            fontFamily: 'Inter',
            fontSize: 24,
            letterSpacing: 0.0,
            fontWeight: FontWeight.w600,
          ),
    ),
  ),
)
