// Generated code for this Text Widget...
Align(
  alignment: AlignmentDirectional(0, 0),
  child: Text(
    'Export notes to text files',
    style: FlutterFlowTheme.of(context).bodyMedium.override(
          fontFamily: 'Inter',
          fontSize: 24,
          letterSpacing: 0.0,
          fontWeight: FontWeight.w600,
        ),
  ),
)
