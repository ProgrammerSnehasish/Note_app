// Generated code for this IconButton Widget...
Padding(
  padding: EdgeInsetsDirectional.fromSTEB(0, 0, 350, 0),
  child: FlutterFlowIconButton(
    borderRadius: 8,
    buttonSize: 40,
    fillColor: FlutterFlowTheme.of(context).primary,
    icon: Icon(
      Icons.arrow_back,
      color: FlutterFlowTheme.of(context).info,
      size: 24,
    ),
    onPressed: () async {
      context.pushNamed('HomePage');
    },
  ),
)
